# Editorial research and asset provenance

Research date: 3 October 2026. The requester explicitly confirmed that this is the official website commissioned for the owner of MariaSM, and requested the channel images and adaptation of the original Canva content. No assets from unrelated accounts were selected.

## Primary sources inspected

- https://www.youtube.com/@mariasmmania — inspected in the browser. Confirms shopping hauls, styling, beauty/fragrance, daily life, travel and sea themes. Selected video IDs and images were read from the rendered channel, not guessed.
- https://www.youtube.com/@mariasmmania/videos — inspected in the browser. Source for additional styling and sea thumbnails.
- https://mariasmmania.my.canva.site/ — inspected in the browser. Confirms shopping, fashion, skincare, homeware, food, garden, nature, sea, travel, gratitude and the public collaboration email. The first-person introduction is adapted from these interests rather than inventing a new biography.

The initial text fetch could not access these sources; browser reading succeeded. This research covers the public pages and visible video descriptions/titles, not transcripts of entire videos. We do not claim to have watched/reviewed each product or each full video.

## Material retained and adapted

The new design retains the personal introduction, shopping-and-lifestyle mix, image-led storytelling, video links and business contact. The English copy was rewritten in a warm poetic voice. The layout, responsive behaviour and visual system are new. Specific health/healing claims in the old site are not repeated as factual treatment advice. No invented testimonials, product testing claims, prices, discounts, affiliate IDs or personal history were added.

## Channel and owner assets

| Delivered file | Source and role |
| --- | --- |
| `docs/assets/maria-profile.jpg` | Public channel avatar, used to identify MariaSM. |
| `docs/assets/channel-banner.jpg` | Actual public channel banner, kept as an image within the new site. |
| `docs/assets/haul.avif` | Official thumbnail for video `Wm4ZHxwCpmA`, higher-resolution version from the rendered Videos page. |
| `docs/assets/style.avif` | Official thumbnail for `fMcqWl3-0Oo`. |
| `docs/assets/seaside.avif` | Official thumbnail for `mQjqFDblWHY`. |
| `docs/assets/summer.avif` | Official thumbnail for `s68jNW-dHTU`. |
| `docs/assets/maria-by-the-sea.webp` | Public personal photo from Canva: `https://mariasmmania.my.canva.site/_assets/media/27560c7c70ef4a8c642332255f5d8a24.jpg`. Optimised to WebP without altering the subject. |

The corresponding full observed channel asset URLs are recorded in `content/channel-assets*.json`. Owner assets are included under the user-confirmed authorisation, **not** claimed to be royalty-free. Rights in any visible third-party brands remain with their owners. Only the channel images and the identified personal photo were taken, not unrelated Canva stock elements or the original Canva welcome artwork.

## Original generated assets

- `docs/assets/editorial-still-life.webp`: original AI-generated still-life of a burgundy cup, blue notebook, fabric, tote and branch; generated for this project, then resized/encoded for the web. No actual product listing or claim about Maria’s home.
- `docs/assets/mediterranean-coast.webp`: original AI-generated coastal mood illustration, not an asserted photograph of a real destination or Maria’s travels.

These image roles are disclosed on the public credits page. Original PNG files remain in the task working assets, outside the distributable repository. No generated people or portraits are used.

## Other assets and design

- New favicon: simple geometric letter M, authored for this website.
- Typography: system Georgia and Arial/Helvetica fallbacks; no external font downloads or redistributed font files.
- Palette: wine `#71243b`, ivory `#fffaf1`, rose `#f0d1d0`, blue `#243da0`.
- Layout: generous editorial typography, a tilted video card, selected video grid, numbered stories, contrasting seaside section and a personal introduction.
- No YouTube video files are downloaded or redistributed. The site opens the original watch pages; videos are not auto-embedded. A simple play symbol is used as a functional icon, not a copied official brand asset.

## Deployment

Workflow reference: https://raw.githubusercontent.com/actions/starter-workflows/main/pages/static.yml (read 3 October 2026). The implementation limits publication to `docs` and adds generation and link checks. GitHub account terms and Pages limits are linked in the README.

## Expanded collections — 3 October 2026

- The first 30 videos were read from the rendered channel Videos tab with Newest selected; the first 10 form the New section, in source order.
- The first 10 entries in the same tab with Popular selected form Most Watched, in source order. This ranking explicitly covers the Videos tab, excluding Shorts and live streams.
- View counts retain YouTube's displayed precision (for example, 6.8K); these are not claimed to be exact counts. Publication ages were translated to English and tied to the snapshot date.
- The collection contains 40 unique video IDs. `content/video-research.json` records observed titles, view labels, publication-age labels and thumbnail URLs. The browser was used to load and acquire the actual thumbnails; no thumbnail URLs were guessed.
- Eight extra Canva photographs were downloaded from observed media URLs and visually inspected as a contact sheet: dresses, two outfit portraits, two beach scenes, a summer collage, a home hot tub and another seaside portrait. Full source URLs and captions are in `content/site.json` under `photos`. They are owner-authorised photographs, not royalty-free stock.
- One video with a health claim in its original title is presented with a neutral editorial heading. The original title remains in the research record; the website does not endorse the claim.
