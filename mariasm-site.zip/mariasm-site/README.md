# MariaSM — A little beauty in the everyday

Sito ufficiale statico preparato per la titolare del canale **@mariasmmania**. Tutte le pagine pubbliche sono in inglese. Progetto indipendente, senza collegamenti al repository precedente.

## Cosa contiene

- Homepage responsive con immagine di Maria, miniature autentiche del canale, video filtrabili, journal, presentazione personale e contatto email.
- Cinque articoli originali completi: casa, shopping consapevole, stile personale, beauty e mare.
- Pagine Privacy e Credits & transparency, coerenti con le funzionalità presenti.
- Immagini locali ottimizzate: niente dipendenze da servizi di foto esterni durante la visita.
- HTML statico utilizzabile anche senza JavaScript; JavaScript serve solo per menu mobile e filtri.
- Nessun account visitatori, database, analytics, newsletter, pagamento o cookie aggiunto dal sito.
- Pubblicazione automatica GitHub Pages con controlli dei collegamenti.

## Anteprima sul computer

Aprire `docs/index.html` nel browser per una visita locale immediata. Per simulare anche il percorso di GitHub Pages:

```sh
npm run preview
```

Aprire `http://127.0.0.1:4186/mariasm-daily-life/`. È un indirizzo locale, non pubblico. Serve Node.js 20 o successivo; nessuna installazione di pacchetti è richiesta.

## Nuovo account: deve essere quello di Maria

1. Maria apre https://github.com/signup e crea personalmente il proprio account con un indirizzo email che controlla, differente da quello del tuo precedente account.
2. Maria sceglie username e password, completa le verifiche richieste e accetta le condizioni direttamente. Non inserire password, codici o token in chat o nei file del progetto.
3. Sceglie il piano **Free**. Per Pages gratuito il repository sarà **pubblico**.
4. Se Maria ha già un account gratuito, usare quello: GitHub limita a un account gratuito personale per persona. Un account di Maria separato dal tuo rispetta la separazione richiesta; cambiare soltanto email non giustifica due account personali gratuiti della stessa persona.
5. Per collaborare, Maria può invitare il tuo account come collaboratore del repository. Non serve condividere la password.

Fonte verificata: https://docs.github.com/en/site-policy/github-terms/github-terms-of-service#b-account-terms

## Pubblicazione consigliata, senza comandi

1. Accedere all’account corretto di Maria e scegliere **New repository**.
2. Nome consigliato: `mariasm-daily-life`. Visibilità: **Public**. Non è necessario aggiungere altri file di avvio.
3. Estrarre `mariasm-site.zip`. Nella pagina del repository usare **uploading an existing file**, oppure **Add file → Upload files**.
4. Caricare il **contenuto** della cartella `mariasm-site`, non lo ZIP e non un’ulteriore cartella contenitore. Devono comparire alla radice `docs`, `content`, `scripts`, `package.json`, `README.md` e `.github`. Non caricare `.git`.
5. Verificare che sia presente `.github/workflows/pages.yml`. Se il caricamento del browser omette la cartella che inizia con un punto, usare **Add file → Create new file**, dare come nome `.github/workflows/pages.yml`, incollare il contenuto del file fornito e salvare.
6. Confermare il caricamento su `main`.
7. Aprire **Settings → Pages → Build and deployment → Source → GitHub Actions**.
8. Aprire **Actions → Publish MariaSM to GitHub Pages → Run workflow** e scegliere `main`. Se la prima esecuzione, avviata prima della configurazione, è fallita, rieseguirla ora.
9. Attendere il completamento e usare il collegamento **Visit site** in Pages. L’indirizzo sarà `https://USERNAME.github.io/mariasm-daily-life/`, dove `USERNAME` è quello realmente scelto da Maria.

Il file del flusso segue il modello ufficiale GitHub e pubblica **solo `docs`**. La documentazione e i file di lavoro non diventano pagine del sito, ma sono visibili nel repository pubblico.

Il repository remoto e la pubblicazione non sono stati eseguiti: manca l’account di destinazione. Non è stato configurato alcun account GitHub precedente.

## Alternativa essenziale: pubblicare da una cartella

Per evitare del tutto il workflow personalizzato, non caricare `.github/workflows/pages.yml` e impostare **Settings → Pages → Deploy from a branch → main → /docs → Save**. La cartella `docs` contiene già il sito completo. Con questa alternativa, dopo ogni modifica ai contenuti bisogna rigenerare e caricare anche `docs`.

## Modificare il sito

- Video, email e link: `content/site.json`.
- Testi delle storie e delle pagine informative: `content/articles.json`.
- Testi e struttura della homepage: `scripts/build.mjs`.
- Colori, spaziature, caratteri e layout: `docs/assets/style.css`.
- Menu e filtri: `docs/assets/app.js`.
- Immagini: `docs/assets/`.

Dopo una modifica:

```sh
npm run build
npm run check
```

Non modificare direttamente le pagine HTML generate se si usa il workflow: verrebbero riscritte alla pubblicazione. Quando l’URL pubblico è noto, inserirlo nel campo `url` di `content/site.json` (con `https://` e il percorso del progetto); il generatore aggiunge i collegamenti canonici corretti. Non è stato inventato un dominio.

## Passaggi da completare con la titolare

- Far leggere a Maria il testo inglese, in particolare la presentazione in prima persona e le informazioni di contatto.
- Confermare che l’autorizzazione all’uso dei materiali copra le fotografie, il banner e le miniature pubblicate; i marchi eventualmente visibili rimangono dei rispettivi titolari.
- Rivedere i dati del titolare e le informazioni privacy applicabili alla gestione effettiva prima della pubblicazione. La pagina attuale descrive il funzionamento del sito, senza inventare dati anagrafici o indirizzi.
- Creare/verificare l’account di Maria e comunicare soltanto lo username pubblico o il link del repository.

## Gratuità e ambito

GitHub Pages è disponibile con GitHub Free per repository pubblici. Il progetto non richiede un dominio a pagamento, servizi esterni a pagamento o un server. È un diario editoriale personale, non un negozio. GitHub Pages pone limiti ai siti principalmente destinati a transazioni commerciali: prima di trasformarlo in e-commerce o in un sito principalmente di vendita/affiliazione occorre rivalutare l’hosting.

Documentazione verificata il 3 ottobre 2026:

- https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
- https://docs.github.com/en/account-and-profile/how-tos/account-management/creating-an-account-on-github

## Licenze e provenienza

Vedere `SOURCES.md`. Non è stata applicata automaticamente una licenza open source che conceda a terzi l’uso delle fotografie o del marchio MariaSM. Un repository pubblico rende il contenuto visibile e soggetto alle condizioni della piattaforma, ma non sostituisce una licenza generale sugli asset.

## Aggiornamento: videoteca ampliata

La homepage ora include **40 video unici**, con categorie Shopping finds, Beauty & fragrance, Watches & accessories, Personal style, Daily life. Il pulsante Show more videos mostra altri gruppi di otto; senza JavaScript la raccolta completa resta leggibile.

**New** contiene i primi 10 video della scheda Video ordinata per più recenti. **Most Watched** contiene i primi 10 della scheda Video ordinata per Popolari. Entrambe escludono Shorts e dirette, come indicato sul sito. Visualizzazioni e date relative sono una fotografia del 3 ottobre 2026: non si aggiornano automaticamente. Il sito riporta esplicitamente data, ambito e arrotondamenti.

Per aggiornare le raccolte, rileggere il canale pubblico e aggiornare `videos`, `newVideos`, `mostWatched` e `verifiedOn` in `content/site.json`, salvando anche i nuovi riscontri in `content/video-research.json` e aggiornando le diciture datate in `scripts/build.mjs`. Mantenere le miniature localmente in `docs/assets/`, poi eseguire build e check. Il controllo confronta l'ordine delle due liste con i riscontri registrati.

La nuova sezione Life, in little frames contiene otto ulteriori foto tratte dal sito Canva della titolare, con didascalie inglesi e apertura dell'immagine completa. I collegamenti alle foto originali sono documentati nella configurazione.
