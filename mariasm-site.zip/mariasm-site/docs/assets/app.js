document.documentElement.classList.add('js');
const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('#navigation');
if (menu && nav) {
  const close = () => { menu.setAttribute('aria-expanded','false'); nav.classList.remove('is-open'); menu.textContent='Menu'; };
  menu.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded',String(open)); nav.classList.toggle('is-open',open); menu.textContent=open?'Close':'Menu';
  });
  nav.addEventListener('click', event => { if(event.target.closest('a')) close(); });
  document.addEventListener('keydown', event => { if(event.key==='Escape' && menu.getAttribute('aria-expanded')==='true'){close();menu.focus();} });
}
const filters=document.querySelector('.filters');
if(filters){
  const cards=[...document.querySelectorAll('#watch [data-category]')];
  const more=document.querySelector('#show-more-videos');
  let selected='all';
  let limit=8;
  const render=()=>{
    const matching=cards.filter(card=>selected==='all'||card.dataset.category===selected);
    cards.forEach(card=>{card.hidden=!matching.includes(card)||matching.indexOf(card)>=limit;});
    more.hidden=matching.length<=limit;
    const label=filters.querySelector('[aria-pressed="true"]').textContent;
    document.querySelector('#filter-status').textContent=`Showing ${Math.min(limit,matching.length)} of ${matching.length} videos · ${label}`;
  };
  filters.hidden=false;
  filters.addEventListener('click',event=>{
    const button=event.target.closest('[data-filter]'); if(!button)return;
    filters.querySelectorAll('button').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));
    selected=button.dataset.filter;limit=8;render();
  });
  more.addEventListener('click',()=>{const previous=cards.filter(c=>!c.hidden);limit+=8;render();const firstNew=cards.find(c=>!c.hidden&&!previous.includes(c));firstNew?.querySelector('a')?.focus({preventScroll:true});});
  render();
}
