import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../docs');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg','.avif':'image/avif','.webp':'image/webp','.png':'image/png','.xml':'application/xml'};
http.createServer((req,res)=>{
  let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);res.end('Bad request');return;}
  // The extra path deliberately tests GitHub Pages project-subdirectory compatibility.
  pathname=pathname.replace(/^\/mariasm-daily-life(?=\/|$)/,'');
  let file=path.resolve(root,'.'+(pathname||'/'));
  if(file!==root && !file.startsWith(root+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('Page not found.');return;}
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});fs.createReadStream(file).pipe(res);
}).listen(4186,'127.0.0.1',()=>console.log('MariaSM preview: http://127.0.0.1:4186/mariasm-daily-life/'));

