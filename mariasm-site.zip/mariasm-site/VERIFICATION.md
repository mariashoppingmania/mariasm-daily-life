# Verification — 3 October 2026

## Completed locally

- Generated eight English HTML pages: homepage, five journal stories, Privacy, Credits & transparency.
- Automated static validation passed: 138 local file/anchor references; one H1 per page; no duplicated IDs; all images have alternative text; metadata present; new-tab links use `noopener`.
- JavaScript syntax check passed.
- Browser checks passed: mobile menu opens and closes, Escape returns focus to the menu button, Daily life filter shows exactly two cards, All moments restores four, story links and the return-home link navigate correctly.
- Browser error log was empty during the interaction checks.
- No horizontal overflow at viewport widths 320, 390, 768 and 1280 pixels.
- No broken loaded images detected. Homepage visually inspected at desktop and mobile sizes.
- Preview tested under `/mariasm-daily-life/`, matching a GitHub Pages project path. Links are relative so another repository name is also supported.
- Actual channel thumbnails, avatar, banner and Canva beach photo were acquired from observed public source URLs and optimised locally where needed.

## Deliberately not claimed

- No remote GitHub repository has been created and no GitHub Pages deployment has run. These require Maria’s actual account and repository.
- The workflow follows the current GitHub static Pages template, but successful publication must be confirmed after it runs in the destination repository.
- This is a curated static video selection, not an automatically synchronised YouTube feed. Update `content/site.json` when changing the selection.
- Browser checks are targeted functional/responsive checks, not a complete accessibility certification or cross-browser audit.
- Initial editorial stories are newly written content for owner review. They do not assert product testing or personal events beyond the source-supported introduction.

## Local repository

Separate Git repository, default branch `main`, no remote configured. Initial files are staged; no commit author identity or credentials were invented. The included browser-upload publication route does not require a local commit.

## Expanded edition — 3 October 2026 (supersedes the four-video checks above)

- Forty unique video records, with five category filters: 6 shopping, 6 beauty, 4 personal style, 15 watches/accessories, 9 daily life/travel.
- Exactly 10 New cards and 10 ordered Most Watched entries, compared against the observed newest-first and Popular source lists.
- Eight additional owner photographs displayed in the new photo diary, with local full-image links.
- 234 local references validated. All eight HTML routes still return HTTP 200; a nonexistent route returns 404.
- Browser interaction checks: Beauty filter shows 6 of 6 correct cards; All moments shows 8 of 40; Show more reveals 16 of 40. Filtering the library does not hide the 10 New cards or the 10 ranking entries.
- Mobile menu opens; selecting New closes it and navigates to the correct section. No browser errors were recorded.
- Responsive checks at 320, 390, 768 and 1280 pixels: no horizontal overflow. No broken loaded images detected. Ranking, New on mobile and the photo gallery were visually inspected and screenshots saved outside the repository.
- Static distribution is approximately 2.7 MB, including forty optimised local thumbnails and the additional owner photographs.
- Remote publication remains pending access to Maria's account. No changes have been made to another GitHub account or repository.
